# Super Smash Trunfo v1.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/lucasgarciadev22/pen/ZEvWgXx](https://codepen.io/lucasgarciadev22/pen/ZEvWgXx).

